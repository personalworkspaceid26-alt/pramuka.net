/*
# Pramuka Attendance System Schema

1. New Tables
- `gudep` — single-row identity/branding config (school name, gudep number, ambalan names, address, phone, pembina, pradana names)
- `students` — member roster (name, NTA/NIS, golongan: Siaga/Penggalang/Penegak/Pandega, gender, active status)
- `sessions` — kegiatan/meeting sessions (date, name, description, golongan filter)
- `attendance` — per-student attendance records linked to sessions (status: Hadir/Izin/Sakit/Alpa, notes)

2. Security
- Single-tenant app (no sign-in). RLS enabled on all tables.
- All policies TO anon, authenticated (data is intentionally shared/public).
*/

-- Gudep identity table (single row, id=1 convention)
CREATE TABLE IF NOT EXISTS gudep (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nama_pangkalan text NOT NULL DEFAULT 'Sekolah Pangkalan Pramuka',
  nomor_gudep text NOT NULL DEFAULT '',
  ambalan_putra text NOT NULL DEFAULT '',
  ambalan_putri text NOT NULL DEFAULT '',
  alamat text NOT NULL DEFAULT '',
  telepon text NOT NULL DEFAULT '',
  nama_pembina text NOT NULL DEFAULT '',
  nip_pembina text NOT NULL DEFAULT '',
  pradana_putra text NOT NULL DEFAULT '',
  pradana_putri text NOT NULL DEFAULT '',
  logo_url text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE gudep ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_gudep" ON gudep;
CREATE POLICY "anon_select_gudep" ON gudep FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_gudep" ON gudep;
CREATE POLICY "anon_insert_gudep" ON gudep FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_gudep" ON gudep;
CREATE POLICY "anon_update_gudep" ON gudep FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_gudep" ON gudep;
CREATE POLICY "anon_delete_gudep" ON gudep FOR DELETE TO anon, authenticated USING (true);

-- Students table
CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nama text NOT NULL,
  nta_nis text NOT NULL DEFAULT '',
  golongan text NOT NULL DEFAULT 'Penggalang' CHECK (golongan IN ('Siaga','Penggalang','Penegak','Pandega')),
  jenis_kelamin text NOT NULL DEFAULT 'L' CHECK (jenis_kelamin IN ('L','P')),
  ambalan text NOT NULL DEFAULT 'Putra' CHECK (ambalan IN ('Putra','Putri')),
  aktif boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE students ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_students" ON students;
CREATE POLICY "anon_select_students" ON students FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_students" ON students;
CREATE POLICY "anon_insert_students" ON students FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_students" ON students;
CREATE POLICY "anon_update_students" ON students FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_students" ON students;
CREATE POLICY "anon_delete_students" ON students FOR DELETE TO anon, authenticated USING (true);

-- Sessions (kegiatan) table
CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nama_kegiatan text NOT NULL,
  tanggal date NOT NULL,
  golongan text NOT NULL DEFAULT 'Semua' CHECK (golongan IN ('Siaga','Penggalang','Penegak','Pandega','Semua')),
  deskripsi text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_sessions" ON sessions;
CREATE POLICY "anon_select_sessions" ON sessions FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_sessions" ON sessions;
CREATE POLICY "anon_insert_sessions" ON sessions FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_sessions" ON sessions;
CREATE POLICY "anon_update_sessions" ON sessions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_sessions" ON sessions;
CREATE POLICY "anon_delete_sessions" ON sessions FOR DELETE TO anon, authenticated USING (true);

-- Attendance table
CREATE TABLE IF NOT EXISTS attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  session_id uuid NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'Hadir' CHECK (status IN ('Hadir','Izin','Sakit','Alpa')),
  keterangan text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  UNIQUE(student_id, session_id)
);

ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_attendance" ON attendance;
CREATE POLICY "anon_select_attendance" ON attendance FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_attendance" ON attendance;
CREATE POLICY "anon_insert_attendance" ON attendance FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_attendance" ON attendance;
CREATE POLICY "anon_update_attendance" ON attendance FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_attendance" ON attendance;
CREATE POLICY "anon_delete_attendance" ON attendance FOR DELETE TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance(student_id);
CREATE INDEX IF NOT EXISTS idx_attendance_session ON attendance(session_id);
CREATE INDEX IF NOT EXISTS idx_sessions_tanggal ON sessions(tanggal);
CREATE INDEX IF NOT EXISTS idx_students_golongan ON students(golongan);

-- Seed default gudep row
INSERT INTO gudep (id, nama_pangkalan, nomor_gudep)
SELECT gen_random_uuid(), 'Sekolah Pangkalan Pramuka', '01-02-03'
WHERE NOT EXISTS (SELECT 1 FROM gudep);
