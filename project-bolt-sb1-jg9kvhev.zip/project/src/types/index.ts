export type Golongan = 'Siaga' | 'Penggalang' | 'Penegak' | 'Pandega';
export type GolonganFilter = Golongan | 'Semua';
export type AttendanceStatus = 'Hadir' | 'Izin' | 'Sakit' | 'Alpa';
export type Ambalan = 'Putra' | 'Putri';
export type JenisKelamin = 'L' | 'P';

export interface Gudep {
  id: string;
  nama_pangkalan: string;
  nomor_gudep: string;
  ambalan_putra: string;
  ambalan_putri: string;
  alamat: string;
  telepon: string;
  nama_pembina: string;
  nip_pembina: string;
  pradana_putra: string;
  pradana_putri: string;
  logo_url: string;
}

export interface Student {
  id: string;
  nama: string;
  nta_nis: string;
  golongan: Golongan;
  jenis_kelamin: JenisKelamin;
  ambalan: Ambalan;
  aktif: boolean;
  created_at: string;
  updated_at: string;
}

export interface Session {
  id: string;
  nama_kegiatan: string;
  tanggal: string;
  golongan: GolonganFilter;
  deskripsi: string;
  created_at: string;
}

export interface AttendanceRecord {
  id: string;
  student_id: string;
  session_id: string;
  status: AttendanceStatus;
  keterangan: string;
  created_at: string;
}

export interface AttendanceWithDetail extends AttendanceRecord {
  student?: Student;
  session?: Session;
}

export const GOLONGAN_LIST: Golongan[] = ['Siaga', 'Penggalang', 'Penegak', 'Pandega'];

export const GOLONGAN_COLORS: Record<Golongan, string> = {
  Siaga: '#84cc16',
  Penggalang: '#22c55e',
  Penegak: '#15803d',
  Pandega: '#166534',
};

export const STATUS_LIST: AttendanceStatus[] = ['Hadir', 'Izin', 'Sakit', 'Alpa'];

export const STATUS_CONFIG: Record<AttendanceStatus, { label: string; bg: string; text: string; dot: string; color: string }> = {
  Hadir: { label: 'Hadir', bg: 'bg-scout-100', text: 'text-scout-700', dot: 'bg-scout-500', color: '#22c55e' },
  Izin: { label: 'Izin', bg: 'bg-blue-100', text: 'text-blue-700', dot: 'bg-blue-500', color: '#3b82f6' },
  Sakit: { label: 'Sakit', bg: 'bg-amber-100', text: 'text-amber-700', dot: 'bg-amber-500', color: '#f59e0b' },
  Alpa: { label: 'Alpa', bg: 'bg-red-100', text: 'text-red-700', dot: 'bg-red-500', color: '#ef4444' },
};

export const GOLONGAN_CONFIG: Record<Golongan, { label: string; bg: string; text: string }> = {
  Siaga: { label: 'Siaga', bg: 'bg-forest-100', text: 'text-forest-700' },
  Penggalang: { label: 'Penggalang', bg: 'bg-scout-100', text: 'text-scout-700' },
  Penegak: { label: 'Penegak', bg: 'bg-teal-100', text: 'text-teal-700' },
  Pandega: { label: 'Pandega', bg: 'bg-emerald-100', text: 'text-emerald-700' },
};
