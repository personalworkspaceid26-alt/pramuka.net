import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { Gudep, Student, AttendanceRecord, Session } from '@/types';
import { STATUS_LIST, STATUS_CONFIG } from '@/types';

interface ExportAttendanceData {
  students: Student[];
  sessions: Session[];
  attendance: AttendanceRecord[];
  gudep: Gudep | null;
  periodeLabel: string;
}

export function exportToExcel({ students, sessions, attendance, gudep, periodeLabel }: ExportAttendanceData) {
  const wb = XLSX.utils.book_new();

  // --- Sheet 1: Rekap Absensi ---
  const recapRows: (string | number)[][] = [];
  recapRows.push(['REKAPITULASI ABSENSI KEGIATAN PRAMUKA']);
  recapRows.push([gudep?.nama_pangkalan || '', 'Gudep:', gudep?.nomor_gudep || '']);
  recapRows.push(['Periode:', periodeLabel]);
  recapRows.push([]);

  const headerRow = ['No', 'Nama', 'NTA/NIS', 'Golongan', 'Ambalan', ...sessions.map((s) => formatDate(s.tanggal)), 'Total Hadir', 'Total Izin', 'Total Sakit', 'Total Alpa', '% Hadir'];
  recapRows.push(headerRow);

  students.forEach((student, idx) => {
    let hadir = 0, izin = 0, sakit = 0, alpa = 0;
    const sessionCols = sessions.map((s) => {
      const rec = attendance.find((a) => a.student_id === student.id && a.session_id === s.id);
      if (rec) {
        if (rec.status === 'Hadir') hadir++;
        else if (rec.status === 'Izin') izin++;
        else if (rec.status === 'Sakit') sakit++;
        else if (rec.status === 'Alpa') alpa++;
        return rec.status.substring(0, 1);
      }
      return '-';
    });
    const total = hadir + izin + sakit + alpa;
    const pct = total > 0 ? Math.round((hadir / total) * 100) : 0;
    recapRows.push([
      idx + 1, student.nama, student.nta_nis, student.golongan, student.ambalan,
      ...sessionCols, hadir, izin, sakit, alpa, `${pct}%`,
    ]);
  });

  const ws = XLSX.utils.aoa_to_sheet(recapRows);
  ws['!cols'] = [
    { wch: 5 }, { wch: 25 }, { wch: 12 }, { wch: 12 }, { wch: 8 },
    ...sessions.map(() => ({ wch: 12 })), { wch: 10 }, { wch: 10 }, { wch: 10 }, { wch: 10 }, { wch: 8 },
  ];
  XLSX.utils.book_append_sheet(wb, ws, 'Rekap Absensi');

  // --- Sheet 2: Detail Absensi ---
  const detailRows: (string | number)[][] = [];
  detailRows.push(['DETAIL ABSENSI PER SESI']);
  detailRows.push([]);

  sessions.forEach((s) => {
    detailRows.push([`Kegiatan: ${s.nama_kegiatan}`, `Tanggal: ${formatDate(s.tanggal)}`]);
    detailRows.push(['No', 'Nama', 'NTA/NIS', 'Golongan', 'Status', 'Keterangan']);
    let no = 1;
    students.forEach((student) => {
      const rec = attendance.find((a) => a.student_id === student.id && a.session_id === s.id);
      if (rec) {
        detailRows.push([no++, student.nama, student.nta_nis, student.golongan, rec.status, rec.keterangan || '-']);
      }
    });
    detailRows.push([]);
  });

  const wsDetail = XLSX.utils.aoa_to_sheet(detailRows);
  wsDetail['!cols'] = [{ wch: 5 }, { wch: 25 }, { wch: 12 }, { wch: 12 }, { wch: 10 }, { wch: 30 }];
  XLSX.utils.book_append_sheet(wb, wsDetail, 'Detail per Sesi');

  // --- Sheet 3: Identitas ---
  if (gudep) {
    const idRows: (string | number)[][] = [];
    idRows.push(['IDENTITAS PANGKALAN / GUDEP']);
    idRows.push([]);
    idRows.push(['Nama Pangkalan', gudep.nama_pangkalan]);
    idRows.push(['Nomor Gudep', gudep.nomor_gudep]);
    idRows.push(['Ambalan Putra', gudep.ambalan_putra]);
    idRows.push(['Ambalan Putri', gudep.ambalan_putri]);
    idRows.push(['Alamat', gudep.alamat]);
    idRows.push(['Telepon', gudep.telepon]);
    idRows.push(['Pembina Gugus Depan', gudep.nama_pembina]);
    idRows.push(['NIP Pembina', gudep.nip_pembina]);
    idRows.push(['Pradana Putra', gudep.pradana_putra]);
    idRows.push(['Pradana Putri', gudep.pradana_putri]);
    const wsId = XLSX.utils.aoa_to_sheet(idRows);
    wsId['!cols'] = [{ wch: 25 }, { wch: 40 }];
    XLSX.utils.book_append_sheet(wb, wsId, 'Identitas Gudep');
  }

  XLSX.writeFile(wb, `Rekap_Absensi_Pramuka_${periodeLabel.replace(/[^a-zA-Z0-9]/g, '_')}.xlsx`);
}

function formatDate(d: string): string {
  const date = new Date(d);
  return date.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function exportToPDF({ students, sessions, attendance, gudep, periodeLabel }: ExportAttendanceData) {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginX = 15;
  const contentWidth = pageWidth - marginX * 2;

  // === KOP SURAT ===
  let yPos = 15;

  // Left logo placeholder
  doc.setDrawColor(22, 101, 67);
  doc.setFillColor(220, 252, 231);
  doc.roundedRect(marginX, yPos, 22, 22, 3, 3, 'FD');
  doc.setFontSize(9);
  doc.setTextColor(22, 101, 67);
  doc.setFont('helvetica', 'bold');
  doc.text('PRAMUKA', marginX + 11, yPos + 11, { align: 'center' });
  doc.setFontSize(6);
  doc.setFont('helvetica', 'normal');
  doc.text('GERAKAN PRAMUKA', marginX + 11, yPos + 16, { align: 'center' });

  // Header text
  const headerX = marginX + 28;
  doc.setTextColor(20, 83, 45);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(gudep?.nama_pangkalan || 'PANGKALAN PRAMUKA', headerX, yPos + 6);

  doc.setFontSize(11);
  doc.text(`AMBALAN ${gudep?.ambalan_putra || '-'}`, headerX, yPos + 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(75, 85, 99);
  const gudepInfo = `Nomor Gudep: ${gudep?.nomor_gudep || '-'}`;
  doc.text(gudepInfo, headerX, yPos + 17);
  const alamatText = gudep?.alamat || '';
  if (alamatText) doc.text(alamatText, headerX, yPos + 21);
  const kontakText = gudep?.telepon ? `Telp: ${gudep.telepon}` : '';
  if (kontakText) doc.text(kontakText, headerX, yPos + 25);

  yPos = Math.max(yPos + 28, yPos + 26);

  // Divider line
  doc.setDrawColor(22, 101, 67);
  doc.setLineWidth(1.5);
  doc.line(marginX, yPos, pageWidth - marginX, yPos);
  doc.setLineWidth(0.3);
  doc.setDrawColor(187, 247, 208);
  doc.line(marginX, yPos + 1.5, pageWidth - marginX, yPos + 1.5);

  yPos += 8;

  // === REPORT TITLE ===
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(17, 24, 39);
  doc.text('LAPORAN REKAPITULASI ABSENSI KEGIATAN PRAMUKA', pageWidth / 2, yPos, { align: 'center' });
  yPos += 5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(75, 85, 99);
  doc.text(`Periode: ${periodeLabel}`, pageWidth / 2, yPos, { align: 'center' });
  yPos += 3;
  doc.text(`Jumlah Sesi: ${sessions.length}  |  Jumlah Siswa: ${students.length}`, pageWidth / 2, yPos, { align: 'center' });
  yPos += 5;

  // === TABLE ===
  const tableHeaders: string[] = ['No', 'Nama Siswa', 'NTA/NIS', 'Golongan', ...sessions.map((s) => formatDate(s.tanggal).substring(0, 10)), '% Hadir'];
  const tableData: (string | number)[][] = students.map((student, idx) => {
    let hadir = 0;
    const totalSessions = sessions.length;
    const sessionCols = sessions.map((s) => {
      const rec = attendance.find((a) => a.student_id === student.id && a.session_id === s.id);
      if (rec) {
        if (rec.status === 'Hadir') hadir++;
        return rec.status.substring(0, 1);
      }
      return '-';
    });
    const pct = totalSessions > 0 ? Math.round((hadir / totalSessions) * 100) : 0;
    return [idx + 1, student.nama, student.nta_nis, student.golongan, ...sessionCols, `${pct}%`];
  });

  autoTable(doc, {
    head: [tableHeaders],
    body: tableData,
    startY: yPos,
    margin: { left: marginX, right: marginX },
    styles: { fontSize: 7, cellPadding: 2, halign: 'center', valign: 'middle' },
    headStyles: { fillColor: [22, 101, 67], textColor: 255, fontStyle: 'bold', fontSize: 7, halign: 'center' },
    bodyStyles: { halign: 'center' },
    columnStyles: {
      0: { cellWidth: 8, halign: 'center' },
      1: { cellWidth: 35, halign: 'left' },
      2: { cellWidth: 18, halign: 'center' },
      3: { cellWidth: 18, halign: 'center' },
    },
    alternateRowStyles: { fillColor: [240, 253, 244] },
    didParseCell: (data) => {
      // Color code status letters
      if (data.section === 'body' && data.column.index >= 4 && data.column.index < 4 + sessions.length) {
        const val = String(data.cell.raw);
        if (val === 'H') { data.cell.styles.textColor = [22, 163, 74]; data.cell.styles.fontStyle = 'bold'; }
        else if (val === 'I') { data.cell.styles.textColor = [59, 130, 246]; data.cell.styles.fontStyle = 'bold'; }
        else if (val === 'S') { data.cell.styles.textColor = [245, 158, 11]; data.cell.styles.fontStyle = 'bold'; }
        else if (val === 'A') { data.cell.styles.textColor = [239, 68, 68]; data.cell.styles.fontStyle = 'bold'; }
        else { data.cell.styles.textColor = [156, 163, 175]; }
      }
    },
  });

  // @ts-expect-error - autoTable adds lastAutoTable to doc
  yPos = doc.lastAutoTable.finalY + 12;

  // === LEGEND ===
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(75, 85, 99);
  let legendX = marginX;
  STATUS_LIST.forEach((status) => {
    const letter = status[0];
    doc.text(`Ket: ${letter} = ${status}`, legendX, yPos);
    legendX += 28;
  });
  yPos += 10;

  // === SIGNATURE BLOCK ===
  const sigY = Math.max(yPos, pageHeight - 50);
  const colW = contentWidth / 2;

  // Left - Pradana
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(17, 24, 39);
  doc.text(`Ambalan ${gudep?.ambalan_putra || '-'},`, marginX, sigY);

  doc.setFont('helvetica', 'bold');
  doc.text('Pradana,', marginX, sigY + 5);

  // Signature space
  doc.setDrawColor(156, 163, 175);
  doc.setLineWidth(0.2);
  doc.line(marginX + 35, sigY + 22, marginX + 70, sigY + 22);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(gudep?.pradana_putra || '..............................', marginX, sigY + 27);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(75, 85, 99);
  if (gudep?.pradana_putra) doc.text(`NTA: ...........`, marginX, sigY + 31);

  // Right - Pembina
  doc.setTextColor(17, 24, 39);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`${gudep?.nama_pangkalan || ''},`, marginX + colW, sigY);

  doc.setFont('helvetica', 'bold');
  doc.text('Pembina Gugus Depan,', marginX + colW, sigY + 5);

  doc.line(marginX + colW + 45, sigY + 22, marginX + colW + 80, sigY + 22);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(gudep?.nama_pembina || '..............................', marginX + colW, sigY + 27);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(75, 85, 99);
  if (gudep?.nip_pembina) doc.text(`NIP: ${gudep.nip_pembina}`, marginX + colW, sigY + 31);

  // === FOOTER ===
  doc.setFontSize(7);
  doc.setTextColor(156, 163, 175);
  doc.text(
    `Dokumen dicetak pada ${new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })}`,
    pageWidth / 2,
    pageHeight - 5,
    { align: 'center' }
  );

  doc.save(`Laporan_Absensi_Pramuka_${periodeLabel.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`);
}
