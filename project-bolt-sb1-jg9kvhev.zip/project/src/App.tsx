import { useEffect, useState } from 'react';
import {
  LayoutDashboard, CalendarCheck, ClipboardList, Users, CalendarDays,
  Settings as SettingsIcon, Menu, X, Tent, ChevronRight, type LucideIcon
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Gudep } from '@/types';
import Dashboard from '@/pages/Dashboard';
import Presensi from '@/pages/Presensi';
import Rekap from '@/pages/Rekap';
import Siswa from '@/pages/Siswa';
import Kegiatan from '@/pages/Kegiatan';
import Pengaturan from '@/pages/Pengaturan';
import { ToastContainer } from '@/components/Toast';
import { FullPageLoader } from '@/components/Loading';

type Page = 'dashboard' | 'presensi' | 'rekap' | 'siswa' | 'kegiatan' | 'pengaturan';

const navItems: { id: Page; label: string; icon: LucideIcon }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'presensi', label: 'Presensi Siswa', icon: CalendarCheck },
  { id: 'rekap', label: 'Rekap Absen', icon: ClipboardList },
  { id: 'siswa', label: 'Data Siswa', icon: Users },
  { id: 'kegiatan', label: 'Kegiatan', icon: CalendarDays },
  { id: 'pengaturan', label: 'Pengaturan', icon: SettingsIcon },
];

const pageTitles: Record<Page, string> = {
  dashboard: 'Dashboard Admin',
  presensi: 'Presensi Siswa',
  rekap: 'Rekap Absen Kegiatan',
  siswa: 'Data Siswa',
  kegiatan: 'Kegiatan Pramuka',
  pengaturan: 'Pengaturan Identitas',
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [gudep, setGudep] = useState<Gudep | null>(null);
  const [loadingGudep, setLoadingGudep] = useState(true);

  useEffect(() => {
    loadGudep();
  }, []);

  async function loadGudep() {
    const { data } = await supabase.from('gudep').select('*').limit(1).maybeSingle();
    if (data) setGudep(data);
    setLoadingGudep(false);
  }

  function navigate(page: string) {
    setCurrentPage(page as Page);
    setSidebarOpen(false);
  }

  if (loadingGudep) {
    return (
      <>
        <FullPageLoader message="Memuat aplikasi..." />
        <ToastContainer />
      </>
    );
  }

  const ambalanDisplay = gudep?.ambalan_putra || gudep?.ambalan_putri
    ? [gudep?.ambalan_putra, gudep?.ambalan_putri].filter(Boolean).join(' / ')
    : 'Ambalan';

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-72 bg-gradient-to-b from-scout-800 to-scout-900 text-white flex flex-col transition-transform duration-300 lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Logo header */}
        <div className="px-5 py-5 flex items-center gap-3 border-b border-white/10">
          <div className="w-11 h-11 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center shrink-0">
            <Tent size={24} className="text-scout-200" />
          </div>
          <div className="min-w-0">
            <h1 className="text-sm font-bold font-display truncate">Sistem Absensi</h1>
            <p className="text-xs text-scout-300 truncate">Pramuka Digital</p>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden ml-auto p-1.5 rounded-lg hover:bg-white/10 transition-colors">
            <X size={18} />
          </button>
        </div>

        {/* Gudep info */}
        <div className="px-5 py-4 border-b border-white/10">
          <div className="space-y-1.5">
            <div>
              <p className="text-[10px] uppercase tracking-wider text-scout-400 font-semibold">Pangkalan</p>
              <p className="text-sm font-semibold truncate">{gudep?.nama_pangkalan || 'Belum diatur'}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-scout-400 font-semibold">Gudep</p>
              <p className="text-sm font-medium text-scout-200 truncate">{gudep?.nomor_gudep || '-'}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-scout-400 font-semibold">Ambalan</p>
              <p className="text-sm font-medium text-scout-200 truncate">{ambalanDisplay}</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  active
                    ? 'bg-white/15 text-white shadow-sm'
                    : 'text-scout-200 hover:bg-white/8 hover:text-white'
                }`}
              >
                <Icon size={19} className={active ? 'text-white' : 'text-scout-300'} />
                <span className="flex-1 text-left">{item.label}</span>
                {active && <ChevronRight size={16} className="text-scout-300" />}
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-white/10">
          <p className="text-[10px] text-scout-400 text-center">
            Gerakan Pramuka Indonesia
          </p>
        </div>
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-gray-900/40 backdrop-blur-sm lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main content */}
      <div className="flex-1 lg:ml-72 min-w-0 flex flex-col">
        {/* Top bar */}
        <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-md border-b border-gray-200">
          <div className="flex items-center gap-3 px-4 lg:px-6 py-3.5">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg text-gray-500 hover:bg-gray-100 transition-colors"
            >
              <Menu size={20} />
            </button>
            <div className="flex-1 min-w-0">
              <h2 className="text-base font-bold text-gray-900 font-display truncate">{pageTitles[currentPage]}</h2>
            </div>
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-scout-50 rounded-lg">
              <Tent size={14} className="text-scout-600" />
              <span className="text-xs font-semibold text-scout-700 truncate max-w-[200px]">
                {gudep?.nama_pangkalan || 'Pangkalan Pramuka'}
              </span>
            </div>
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-gray-50 rounded-lg">
              <span className="text-xs font-medium text-gray-500">Gudep:</span>
              <span className="text-xs font-bold text-gray-700">{gudep?.nomor_gudep || '-'}</span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 lg:p-6 overflow-x-hidden">
          {currentPage === 'dashboard' && <Dashboard gudep={gudep} onNavigate={navigate} />}
          {currentPage === 'presensi' && <Presensi />}
          {currentPage === 'rekap' && <Rekap gudep={gudep} />}
          {currentPage === 'siswa' && <Siswa />}
          {currentPage === 'kegiatan' && <Kegiatan />}
          {currentPage === 'pengaturan' && <Pengaturan gudep={gudep} onGudepChange={setGudep} />}
        </main>
      </div>

      <ToastContainer />
    </div>
  );
}
