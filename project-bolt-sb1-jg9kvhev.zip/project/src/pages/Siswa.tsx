import { useEffect, useState } from 'react';
import { UserPlus, Search, Edit2, Trash2, Users, Filter } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { GOLONGAN_LIST, GOLONGAN_CONFIG } from '@/types';
import type { Student, Golongan, Ambalan, JenisKelamin } from '@/types';
import { FullPageLoader } from '@/components/Loading';
import { EmptyState } from '@/components/EmptyState';
import Modal from '@/components/Modal';
import ConfirmDialog from '@/components/ConfirmDialog';
import { toast } from '@/components/Toast';

export default function Siswa() {
  const [loading, setLoading] = useState(true);
  const [students, setStudents] = useState<Student[]>([]);
  const [search, setSearch] = useState('');
  const [golFilter, setGolFilter] = useState<string>('Semua');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Student | null>(null);
  const [form, setForm] = useState({ nama: '', nta_nis: '', golongan: 'Penggalang' as Golongan, ambalan: 'Putra' as Ambalan, jenis_kelamin: 'L' as JenisKelamin, aktif: true });
  const [saving, setSaving] = useState(false);

  useEffect(() => { loadStudents(); }, []);

  async function loadStudents() {
    setLoading(true);
    const { data } = await supabase.from('students').select('*').order('nama');
    setStudents(data || []);
    setLoading(false);
  }

  const filtered = students.filter((s) => {
    if (golFilter !== 'Semua' && s.golongan !== golFilter) return false;
    if (search && !s.nama.toLowerCase().includes(search.toLowerCase()) && !s.nta_nis.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  function openAdd() {
    setEditing(null);
    setForm({ nama: '', nta_nis: '', golongan: 'Penggalang', ambalan: 'Putra', jenis_kelamin: 'L', aktif: true });
    setModalOpen(true);
  }

  function openEdit(s: Student) {
    setEditing(s);
    setForm({ nama: s.nama, nta_nis: s.nta_nis, golongan: s.golongan, ambalan: s.ambalan, jenis_kelamin: s.jenis_kelamin, aktif: s.aktif });
    setModalOpen(true);
  }

  async function handleSave() {
    if (!form.nama.trim()) { toast('error', 'Nama siswa wajib diisi'); return; }
    setSaving(true);
    try {
      if (editing) {
        const { error } = await supabase.from('students').update({ ...form, updated_at: new Date().toISOString() }).eq('id', editing.id);
        if (error) throw error;
        toast('success', 'Data siswa berhasil diperbarui');
      } else {
        const { error } = await supabase.from('students').insert({ ...form });
        if (error) throw error;
        toast('success', 'Siswa baru berhasil ditambahkan');
      }
      setModalOpen(false);
      await loadStudents();
    } catch {
      toast('error', 'Gagal menyimpan data siswa');
    }
    setSaving(false);
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    const { error } = await supabase.from('students').delete().eq('id', deleteTarget.id);
    if (error) {
      toast('error', 'Gagal menghapus siswa');
    } else {
      toast('success', 'Siswa berhasil dihapus');
      await loadStudents();
    }
    setDeleteTarget(null);
  }

  if (loading) return <FullPageLoader message="Memuat data siswa..." />;

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header + actions */}
      <div className="card p-5">
        <div className="flex flex-col sm:flex-row gap-3 sm:items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-gray-900 font-display">Data Siswa</h2>
            <p className="text-xs text-gray-400 mt-0.5">{students.length} siswa terdaftar, {students.filter(s => s.aktif).length} aktif</p>
          </div>
          <button onClick={openAdd} className="btn-primary">
            <UserPlus size={18} /> Tambah Siswa
          </button>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 mt-4">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input type="text" placeholder="Cari nama atau NTA/NIS..." value={search} onChange={(e) => setSearch(e.target.value)} className="input-field pl-9" />
          </div>
          <div className="flex items-center gap-1.5 bg-gray-100 p-1 rounded-lg overflow-x-auto">
            <Filter size={14} className="text-gray-400 ml-1.5 shrink-0" />
            <button onClick={() => setGolFilter('Semua')} className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all whitespace-nowrap ${golFilter === 'Semua' ? 'bg-white text-scout-700 shadow-sm' : 'text-gray-500'}`}>Semua</button>
            {GOLONGAN_LIST.map((g) => (
              <button key={g} onClick={() => setGolFilter(g)} className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all whitespace-nowrap ${golFilter === g ? 'bg-white text-scout-700 shadow-sm' : 'text-gray-500'}`}>{g}</button>
            ))}
          </div>
        </div>
      </div>

      {/* Table */}
      {filtered.length > 0 ? (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase px-4 py-3">Nama</th>
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase px-4 py-3 hidden sm:table-cell">NTA/NIS</th>
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase px-4 py-3">Golongan</th>
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase px-4 py-3 hidden md:table-cell">Ambalan</th>
                  <th className="text-center text-xs font-semibold text-gray-500 uppercase px-4 py-3 hidden lg:table-cell">Status</th>
                  <th className="text-right text-xs font-semibold text-gray-500 uppercase px-4 py-3">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filtered.map((s) => {
                  const golCfg = GOLONGAN_CONFIG[s.golongan];
                  return (
                    <tr key={s.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className={`w-9 h-9 rounded-full ${s.ambalan === 'Putra' ? 'bg-blue-100' : 'bg-pink-100'} flex items-center justify-center text-sm font-bold ${s.ambalan === 'Putra' ? 'text-blue-600' : 'text-pink-600'}`}>
                            {s.nama.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-gray-900">{s.nama}</p>
                            <p className="text-xs text-gray-400 sm:hidden">{s.nta_nis || '-'}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600 hidden sm:table-cell">{s.nta_nis || '-'}</td>
                      <td className="px-4 py-3"><span className={`badge ${golCfg.bg} ${golCfg.text}`}>{s.golongan}</span></td>
                      <td className="px-4 py-3 hidden md:table-cell">
                        <span className={`badge ${s.ambalan === 'Putra' ? 'bg-blue-100 text-blue-700' : 'bg-pink-100 text-pink-700'}`}>{s.ambalan}</span>
                      </td>
                      <td className="px-4 py-3 text-center hidden lg:table-cell">
                        <span className={`badge ${s.aktif ? 'bg-scout-100 text-scout-700' : 'bg-gray-100 text-gray-500'}`}>
                          {s.aktif ? 'Aktif' : 'Nonaktif'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1 justify-end">
                          <button onClick={() => openEdit(s)} className="p-2 rounded-lg text-gray-400 hover:text-scout-600 hover:bg-scout-50 transition-colors">
                            <Edit2 size={16} />
                          </button>
                          <button onClick={() => setDeleteTarget(s)} className="p-2 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors">
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="card">
          <EmptyState
            icon={Users}
            title={search || golFilter !== 'Semua' ? "Tidak ada siswa yang sesuai" : "Belum ada siswa"}
            message={search || golFilter !== 'Semua' ? "Coba ubah kata kunci atau filter pencarian." : "Tambahkan data siswa pramuka untuk mulai mencatat presensi."}
            action={!(search || golFilter !== 'Semua') && <button onClick={openAdd} className="btn-primary text-sm"><UserPlus size={16} /> Tambah Siswa</button>}
          />
        </div>
      )}

      {/* Add/Edit Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Siswa' : 'Tambah Siswa Baru'}>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Nama Lengkap <span className="text-red-500">*</span></label>
            <input type="text" value={form.nama} onChange={(e) => setForm({ ...form, nama: e.target.value })} className="input-field" placeholder="Masukkan nama lengkap" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">NTA / NIS</label>
            <input type="text" value={form.nta_nis} onChange={(e) => setForm({ ...form, nta_nis: e.target.value })} className="input-field" placeholder="Nomor Tanda Anggota / NIS" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Golongan</label>
              <select value={form.golongan} onChange={(e) => setForm({ ...form, golongan: e.target.value as Golongan })} className="input-field">
                {GOLONGAN_LIST.map((g) => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Ambalan</label>
              <select value={form.ambalan} onChange={(e) => setForm({ ...form, ambalan: e.target.value as Ambalan })} className="input-field">
                <option value="Putra">Putra</option>
                <option value="Putri">Putri</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Jenis Kelamin</label>
              <select value={form.jenis_kelamin} onChange={(e) => setForm({ ...form, jenis_kelamin: e.target.value as JenisKelamin })} className="input-field">
                <option value="L">Laki-laki</option>
                <option value="P">Perempuan</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Status</label>
              <select value={form.aktif ? '1' : '0'} onChange={(e) => setForm({ ...form, aktif: e.target.value === '1' })} className="input-field">
                <option value="1">Aktif</option>
                <option value="0">Nonaktif</option>
              </select>
            </div>
          </div>
          <div className="flex gap-3 justify-end pt-2">
            <button onClick={() => setModalOpen(false)} className="btn-secondary">Batal</button>
            <button onClick={handleSave} disabled={saving} className="btn-primary">
              {saving ? 'Menyimpan...' : editing ? 'Simpan Perubahan' : 'Tambah Siswa'}
            </button>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Hapus Siswa"
        message={`Yakin ingin menghapus "${deleteTarget?.nama}"? Semua data absensi terkait juga akan dihapus.`}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
