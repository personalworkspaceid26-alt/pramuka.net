import { useEffect, useState } from 'react';
import { CalendarPlus, Edit2, Trash2, CalendarDays, MapPin } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { GOLONGAN_LIST } from '@/types';
import type { Session, GolonganFilter, AttendanceRecord } from '@/types';
import { FullPageLoader } from '@/components/Loading';
import { EmptyState } from '@/components/EmptyState';
import Modal from '@/components/Modal';
import ConfirmDialog from '@/components/ConfirmDialog';
import { toast } from '@/components/Toast';

export default function Kegiatan() {
  const [loading, setLoading] = useState(true);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Session | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Session | null>(null);
  const [form, setForm] = useState({ nama_kegiatan: '', tanggal: new Date().toISOString().split('T')[0], golongan: 'Semua' as GolonganFilter, deskripsi: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    setLoading(true);
    const [sessRes, attRes] = await Promise.all([
      supabase.from('sessions').select('*').order('tanggal', { ascending: false }),
      supabase.from('attendance').select('*'),
    ]);
    setSessions(sessRes.data || []);
    setAttendance(attRes.data || []);
    setLoading(false);
  }

  function openAdd() {
    setEditing(null);
    setForm({ nama_kegiatan: '', tanggal: new Date().toISOString().split('T')[0], golongan: 'Semua', deskripsi: '' });
    setModalOpen(true);
  }

  function openEdit(s: Session) {
    setEditing(s);
    setForm({ nama_kegiatan: s.nama_kegiatan, tanggal: s.tanggal, golongan: s.golongan, deskripsi: s.deskripsi || '' });
    setModalOpen(true);
  }

  async function handleSave() {
    if (!form.nama_kegiatan.trim()) { toast('error', 'Nama kegiatan wajib diisi'); return; }
    if (!form.tanggal) { toast('error', 'Tanggal kegiatan wajib diisi'); return; }
    setSaving(true);
    try {
      if (editing) {
        const { error } = await supabase.from('sessions').update(form).eq('id', editing.id);
        if (error) throw error;
        toast('success', 'Kegiatan berhasil diperbarui');
      } else {
        const { error } = await supabase.from('sessions').insert(form);
        if (error) throw error;
        toast('success', 'Kegiatan baru berhasil ditambahkan');
      }
      setModalOpen(false);
      await loadData();
    } catch {
      toast('error', 'Gagal menyimpan kegiatan');
    }
    setSaving(false);
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    const { error } = await supabase.from('sessions').delete().eq('id', deleteTarget.id);
    if (error) {
      toast('error', 'Gagal menghapus kegiatan');
    } else {
      toast('success', 'Kegiatan berhasil dihapus');
      await loadData();
    }
    setDeleteTarget(null);
  }

  if (loading) return <FullPageLoader message="Memuat data kegiatan..." />;

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="card p-5">
        <div className="flex flex-col sm:flex-row gap-3 sm:items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-gray-900 font-display">Kegiatan Pramuka</h2>
            <p className="text-xs text-gray-400 mt-0.5">{sessions.length} sesi kegiatan tercatat</p>
          </div>
          <button onClick={openAdd} className="btn-primary">
            <CalendarPlus size={18} /> Tambah Kegiatan
          </button>
        </div>
      </div>

      {sessions.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sessions.map((s, i) => {
            const sAtt = attendance.filter((a) => a.session_id === s.id);
            const hadir = sAtt.filter((a) => a.status === 'Hadir').length;
            const date = new Date(s.tanggal);
            return (
              <div key={s.id} className="card p-5 animate-slide-up" style={{ animationDelay: `${i * 50}ms` }}>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-scout-50 flex flex-col items-center justify-center shrink-0">
                      <span className="text-xs font-bold text-scout-700 leading-none">{date.getDate()}</span>
                      <span className="text-[10px] text-scout-500 leading-none mt-0.5">
                        {date.toLocaleDateString('id-ID', { month: 'short' })}
                      </span>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">
                        {date.toLocaleDateString('id-ID', { weekday: 'long' })}
                      </p>
                      <p className="text-xs text-gray-400">{date.getFullYear()}</p>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => openEdit(s)} className="p-1.5 rounded-lg text-gray-400 hover:text-scout-600 hover:bg-scout-50 transition-colors">
                      <Edit2 size={15} />
                    </button>
                    <button onClick={() => setDeleteTarget(s)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors">
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
                <h3 className="text-sm font-bold text-gray-900 mb-2">{s.nama_kegiatan}</h3>
                {s.deskripsi && (
                  <p className="text-xs text-gray-500 mb-3 line-clamp-2">{s.deskripsi}</p>
                )}
                <div className="flex items-center gap-2 flex-wrap pt-3 border-t border-gray-100">
                  <span className={`badge ${s.golongan === 'Semua' ? 'bg-gray-100 text-gray-600' : 'bg-scout-100 text-scout-700'}`}>
                    {s.golongan}
                  </span>
                  <span className="badge bg-scout-50 text-scout-600">{hadir} hadir</span>
                  <span className="badge bg-gray-100 text-gray-500">{sAtt.length} total</span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="card">
          <EmptyState
            icon={CalendarDays}
            title="Belum ada kegiatan"
            message="Tambahkan sesi kegiatan pramuka untuk mulai mencatat presensi siswa."
            action={<button onClick={openAdd} className="btn-primary text-sm"><CalendarPlus size={16} /> Tambah Kegiatan</button>}
          />
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Kegiatan' : 'Tambah Kegiatan Baru'}>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Nama Kegiatan <span className="text-red-500">*</span></label>
            <input type="text" value={form.nama_kegiatan} onChange={(e) => setForm({ ...form, nama_kegiatan: e.target.value })} className="input-field" placeholder="Contoh: Latihan Rutin Mingguan" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Tanggal <span className="text-red-500">*</span></label>
              <input type="date" value={form.tanggal} onChange={(e) => setForm({ ...form, tanggal: e.target.value })} className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Golongan</label>
              <select value={form.golongan} onChange={(e) => setForm({ ...form, golongan: e.target.value as GolonganFilter })} className="input-field">
                <option value="Semua">Semua Golongan</option>
                {GOLONGAN_LIST.map((g) => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Deskripsi</label>
            <textarea value={form.deskripsi} onChange={(e) => setForm({ ...form, deskripsi: e.target.value })} className="input-field min-h-[80px] resize-y" placeholder="Deskripsi singkat kegiatan (opsional)" />
          </div>
          <div className="flex gap-3 justify-end pt-2">
            <button onClick={() => setModalOpen(false)} className="btn-secondary">Batal</button>
            <button onClick={handleSave} disabled={saving} className="btn-primary">
              {saving ? 'Menyimpan...' : editing ? 'Simpan Perubahan' : 'Tambah Kegiatan'}
            </button>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Hapus Kegiatan"
        message={`Yakin ingin menghapus "${deleteTarget?.nama_kegiatan}"? Semua data absensi terkait juga akan dihapus.`}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
