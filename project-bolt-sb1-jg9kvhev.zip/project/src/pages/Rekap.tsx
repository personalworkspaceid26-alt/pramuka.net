import { useEffect, useState, useMemo } from 'react';
import { CalendarRange, FileDown, FileSpreadsheet, TrendingUp, BarChart3, Users } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { GOLONGAN_LIST, STATUS_CONFIG, GOLONGAN_COLORS } from '@/types';
import type { Gudep, Student, Session, AttendanceRecord, GolonganFilter } from '@/types';
import { FullPageLoader } from '@/components/Loading';
import { EmptyState } from '@/components/EmptyState';
import BarChart from '@/components/BarChart';
import { exportToPDF, exportToExcel } from '@/lib/export';
import { toast } from '@/components/Toast';

interface RekapProps {
  gudep: Gudep | null;
}

type PeriodMode = 'mingguan' | 'bulanan' | 'tahunan';

export default function Rekap({ gudep }: RekapProps) {
  const [loading, setLoading] = useState(true);
  const [students, setStudents] = useState<Student[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [period, setPeriod] = useState<PeriodMode>('bulanan');
  const [golonganFilter, setGolonganFilter] = useState<GolonganFilter>('Semua');
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth());

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    const [studentsRes, sessionsRes, attendanceRes] = await Promise.all([
      supabase.from('students').select('*').order('nama'),
      supabase.from('sessions').select('*').order('tanggal', { ascending: false }),
      supabase.from('attendance').select('*'),
    ]);
    setStudents(studentsRes.data || []);
    setSessions(sessionsRes.data || []);
    setAttendance(attendanceRes.data || []);
    setLoading(false);
  }

  const monthNames = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

  const filteredSessions = useMemo(() => {
    return sessions.filter((s) => {
      const d = new Date(s.tanggal);
      if (period === 'tahunan') {
        return d.getFullYear() === year;
      } else if (period === 'bulanan') {
        return d.getFullYear() === year && d.getMonth() === month;
      } else {
        // mingguan - current week
        const now = new Date();
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - now.getDay());
        weekStart.setHours(0, 0, 0, 0);
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 6);
        weekEnd.setHours(23, 59, 59, 999);
        return d >= weekStart && d <= weekEnd;
      }
    });
  }, [sessions, period, year, month]);

  const filteredStudents = students.filter((s) => {
    if (golonganFilter !== 'Semua' && s.golongan !== golonganFilter) return false;
    return s.aktif;
  });

  const sessionIds = new Set(filteredSessions.map((s) => s.id));

  const relevantAttendance = attendance.filter((a) => sessionIds.has(a.session_id));

  const recapData = filteredStudents.map((student) => {
    let hadir = 0, izin = 0, sakit = 0, alpa = 0;
    filteredSessions.forEach((sess) => {
      const rec = attendance.find((a) => a.student_id === student.id && a.session_id === sess.id);
      if (rec) {
        if (rec.status === 'Hadir') hadir++;
        else if (rec.status === 'Izin') izin++;
        else if (rec.status === 'Sakit') sakit++;
        else if (rec.status === 'Alpa') alpa++;
      }
    });
    const total = hadir + izin + sakit + alpa;
    const pct = total > 0 ? Math.round((hadir / total) * 100) : 0;
    return { student, hadir, izin, sakit, alpa, total, pct };
  });

  const avgAttendance = recapData.length > 0
    ? Math.round(recapData.reduce((sum, d) => sum + d.pct, 0) / recapData.length)
    : 0;

  const golonganAttendance = GOLONGAN_LIST.map((g) => {
    const gStudents = filteredStudents.filter((s) => s.golongan === g);
    const gStudentIds = new Set(gStudents.map((s) => s.id));
    const gAtt = relevantAttendance.filter((a) => gStudentIds.has(a.student_id));
    const hadir = gAtt.filter((a) => a.status === 'Hadir').length;
    const total = gAtt.length;
    const pct = total > 0 ? Math.round((hadir / total) * 100) : 0;
    return { label: g, value: pct, color: GOLONGAN_COLORS[g] };
  });

  const periodLabel = period === 'tahunan' ? `Tahun ${year}` : period === 'bulanan' ? `${monthNames[month]} ${year}` : `Minggu Ini`;

  function handleExportPDF() {
    if (filteredSessions.length === 0 || filteredStudents.length === 0) {
      toast('info', 'Tidak ada data untuk periode ini.');
      return;
    }
    exportToPDF({ students: filteredStudents, sessions: filteredSessions, attendance: relevantAttendance, gudep, periodeLabel: periodLabel });
    toast('success', 'Laporan PDF berhasil diunduh');
  }

  function handleExportExcel() {
    if (filteredSessions.length === 0 || filteredStudents.length === 0) {
      toast('info', 'Tidak ada data untuk periode ini.');
      return;
    }
    exportToExcel({ students: filteredStudents, sessions: filteredSessions, attendance: relevantAttendance, gudep, periodeLabel: periodLabel });
    toast('success', 'Laporan Excel berhasil diunduh');
  }

  if (loading) return <FullPageLoader message="Memuat rekap absensi..." />;

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Filters */}
      <div className="card p-5">
        <div className="flex flex-col gap-4">
          <div className="flex flex-col sm:flex-row gap-3 sm:items-center">
            <div className="flex gap-1.5 bg-gray-100 p-1 rounded-lg">
              {(['mingguan', 'bulanan', 'tahunan'] as PeriodMode[]).map((p) => (
                <button
                  key={p}
                  onClick={() => setPeriod(p)}
                  className={`px-4 py-2 text-sm font-semibold rounded-md transition-all capitalize ${period === p ? 'bg-white text-scout-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  {p}
                </button>
              ))}
            </div>

            {period === 'bulanan' && (
              <div className="flex gap-2">
                <select value={month} onChange={(e) => setMonth(Number(e.target.value))} className="input-field flex-1">
                  {monthNames.map((m, i) => <option key={i} value={i}>{m}</option>)}
                </select>
                <select value={year} onChange={(e) => setYear(Number(e.target.value))} className="input-field w-28">
                  {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - 2 + i).map((y) => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>
              </div>
            )}

            {period === 'tahunan' && (
              <select value={year} onChange={(e) => setYear(Number(e.target.value))} className="input-field w-32">
                {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - 2 + i).map((y) => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            )}

            <div className="flex gap-1.5 bg-gray-100 p-1 rounded-lg">
              <button
                onClick={() => setGolonganFilter('Semua')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${golonganFilter === 'Semua' ? 'bg-white text-scout-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                Semua
              </button>
              {GOLONGAN_LIST.map((g) => (
                <button
                  key={g}
                  onClick={() => setGolonganFilter(g)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${golonganFilter === g ? 'bg-white text-scout-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  {g}
                </button>
              ))}
            </div>

            <div className="flex gap-2 sm:ml-auto">
              <button onClick={handleExportPDF} className="btn-primary text-sm">
                <FileDown size={16} /> PDF
              </button>
              <button onClick={handleExportExcel} className="btn-secondary text-sm">
                <FileSpreadsheet size={16} /> Excel
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-4">
          <div className="flex items-center gap-2 mb-1.5">
            <CalendarRange size={16} className="text-scout-600" />
            <span className="text-xs font-semibold text-gray-500">Total Pertemuan</span>
          </div>
          <span className="text-2xl font-bold text-gray-900 font-display">{filteredSessions.length}</span>
          <span className="text-xs text-gray-400 block mt-0.5">sesi terlaksana</span>
        </div>
        <div className="card p-4">
          <div className="flex items-center gap-2 mb-1.5">
            <TrendingUp size={16} className="text-forest-600" />
            <span className="text-xs font-semibold text-gray-500">Rata-rata Kehadiran</span>
          </div>
          <span className="text-2xl font-bold text-gray-900 font-display">{avgAttendance}%</span>
          <span className="text-xs text-gray-400 block mt-0.5">dari {filteredStudents.length} siswa</span>
        </div>
        <div className="card p-4">
          <div className="flex items-center gap-2 mb-1.5">
            <Users size={16} className="text-earth-600" />
            <span className="text-xs font-semibold text-gray-500">Total Absensi</span>
          </div>
          <span className="text-2xl font-bold text-gray-900 font-display">{relevantAttendance.length}</span>
          <span className="text-xs text-gray-400 block mt-0.5">rekaman tercatat</span>
        </div>
        <div className="card p-4">
          <div className="flex items-center gap-2 mb-1.5">
            <BarChart3 size={16} className="text-blue-600" />
            <span className="text-xs font-semibold text-gray-500">Periode</span>
          </div>
          <span className="text-lg font-bold text-gray-900 font-display">{periodLabel}</span>
        </div>
      </div>

      {/* Golongan bar chart */}
      {relevantAttendance.length > 0 && (
        <div className="card p-6">
          <h2 className="text-sm font-bold text-gray-900 mb-1">Tingkat Kehadiran per Golongan</h2>
          <p className="text-xs text-gray-400 mb-5">Periode: {periodLabel}</p>
          <BarChart data={golonganAttendance} />
        </div>
      )}

      {/* Matrix table */}
      {filteredSessions.length > 0 && filteredStudents.length > 0 ? (
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100">
            <h2 className="text-sm font-bold text-gray-900">Matriks Kehadiran Siswa</h2>
            <p className="text-xs text-gray-400 mt-0.5">Rekapitulasi kehadiran per siswa — {periodLabel}</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase px-4 py-3 sticky left-0 bg-gray-50">Nama</th>
                  <th className="text-center text-xs font-semibold text-gray-500 uppercase px-3 py-3">Golongan</th>
                  <th className="text-center text-xs font-semibold text-gray-500 uppercase px-3 py-3 bg-scout-50">Hadir</th>
                  <th className="text-center text-xs font-semibold text-gray-500 uppercase px-3 py-3">Izin</th>
                  <th className="text-center text-xs font-semibold text-gray-500 uppercase px-3 py-3">Sakit</th>
                  <th className="text-center text-xs font-semibold text-gray-500 uppercase px-3 py-3">Alpa</th>
                  <th className="text-center text-xs font-semibold text-gray-500 uppercase px-3 py-3">% Hadir</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {recapData.map(({ student, hadir, izin, sakit, alpa, pct }) => (
                  <tr key={student.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-4 py-3 sticky left-0 bg-white">
                      <div className="flex items-center gap-2">
                        <div className={`w-7 h-7 rounded-full ${student.ambalan === 'Putra' ? 'bg-blue-100' : 'bg-pink-100'} flex items-center justify-center text-xs font-bold ${student.ambalan === 'Putra' ? 'text-blue-600' : 'text-pink-600'}`}>
                          {student.nama.charAt(0).toUpperCase()}
                        </div>
                        <span className="text-sm font-semibold text-gray-900">{student.nama}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className="badge bg-gray-100 text-gray-600">{student.golongan}</span>
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className="text-sm font-bold text-scout-600 tabular-nums">{hadir}</span>
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className="text-sm font-semibold text-blue-600 tabular-nums">{izin}</span>
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className="text-sm font-semibold text-amber-600 tabular-nums">{sakit}</span>
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className="text-sm font-semibold text-red-600 tabular-nums">{alpa}</span>
                    </td>
                    <td className="px-3 py-3 text-center">
                      <div className="flex items-center gap-2 justify-center">
                        <div className="w-16 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{ width: `${pct}%`, background: pct >= 75 ? '#22c55e' : pct >= 50 ? '#f59e0b' : '#ef4444' }}
                          />
                        </div>
                        <span className="text-xs font-bold text-gray-700 tabular-nums w-9 text-right">{pct}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="card">
          <EmptyState
            icon={CalendarRange}
            title="Tidak ada data untuk periode ini"
            message="Belum ada sesi kegiatan atau data absensi pada periode yang dipilih. Coba ubah periode atau tambahkan kegiatan."
          />
        </div>
      )}
    </div>
  );
}
