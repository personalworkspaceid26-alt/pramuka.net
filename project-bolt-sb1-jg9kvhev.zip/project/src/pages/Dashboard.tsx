import { useEffect, useState } from 'react';
import { Users, CalendarDays, TrendingUp, FileDown, FileSpreadsheet, Award, Activity } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { GOLONGAN_LIST, GOLONGAN_COLORS, STATUS_CONFIG } from '@/types';
import type { Gudep, Student, Session, AttendanceRecord, Golongan } from '@/types';
import DonutChart from '@/components/DonutChart';
import BarChart from '@/components/BarChart';
import { FullPageLoader } from '@/components/Loading';
import { EmptyState } from '@/components/EmptyState';
import { exportToPDF, exportToExcel } from '@/lib/export';
import { toast } from '@/components/Toast';

interface DashboardProps {
  gudep: Gudep | null;
  onNavigate: (page: string) => void;
}

export default function Dashboard({ gudep, onNavigate }: DashboardProps) {
  const [loading, setLoading] = useState(true);
  const [students, setStudents] = useState<Student[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    const [studentsRes, sessionsRes, attendanceRes] = await Promise.all([
      supabase.from('students').select('*').order('nama'),
      supabase.from('sessions').select('*').order('tanggal', { ascending: false }),
      supabase.from('attendance').select('*'),
    ]);
    setStudents(studentsRes.data || []);
    setSessions(sessionsRes.data || []);
    setAttendance(attendanceRes.data || []);
    setLoading(false);
  }

  const activeStudents = students.filter((s) => s.aktif);

  // Donut: golongan distribution
  const golonganData = GOLONGAN_LIST.map((g) => ({
    label: g,
    value: activeStudents.filter((s) => s.golongan === g).length,
    color: GOLONGAN_COLORS[g],
  }));

  // Bar: attendance rate per golongan
  const golonganAttendance = GOLONGAN_LIST.map((g) => {
    const gStudents = activeStudents.filter((s) => s.golongan === g);
    const gStudentIds = new Set(gStudents.map((s) => s.id));
    const gAttendance = attendance.filter((a) => gStudentIds.has(a.student_id));
    const hadir = gAttendance.filter((a) => a.status === 'Hadir').length;
    const total = gAttendance.length;
    const pct = total > 0 ? Math.round((hadir / total) * 100) : 0;
    return { label: g, value: pct, color: GOLONGAN_COLORS[g] };
  });

  // Overall attendance rate
  const totalHadir = attendance.filter((a) => a.status === 'Hadir').length;
  const overallPct = attendance.length > 0 ? Math.round((totalHadir / attendance.length) * 100) : 0;

  // Sessions this week
  const now = new Date();
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - now.getDay());
  weekStart.setHours(0, 0, 0, 0);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 6);
  weekEnd.setHours(23, 59, 59, 999);
  const sessionsThisWeek = sessions.filter((s) => {
    const d = new Date(s.tanggal);
    return d >= weekStart && d <= weekEnd;
  });

  // Status breakdown
  const statusData = [
    { label: 'Hadir', value: attendance.filter((a) => a.status === 'Hadir').length, color: STATUS_CONFIG.Hadir.color },
    { label: 'Izin', value: attendance.filter((a) => a.status === 'Izin').length, color: STATUS_CONFIG.Izin.color },
    { label: 'Sakit', value: attendance.filter((a) => a.status === 'Sakit').length, color: STATUS_CONFIG.Sakit.color },
    { label: 'Alpa', value: attendance.filter((a) => a.status === 'Alpa').length, color: STATUS_CONFIG.Alpa.color },
  ];

  const stats = [
    { label: 'Anggota Aktif', value: activeStudents.length, icon: Users, color: 'scout', sub: `${students.length} total terdaftar` },
    { label: 'Rata-rata Presensi', value: `${overallPct}%`, icon: TrendingUp, color: 'forest', sub: `${totalHadir} dari ${attendance.length} total` },
    { label: 'Sesi Minggu Ini', value: sessionsThisWeek.length, icon: CalendarDays, color: 'earth', sub: `${sessions.length} total sesi` },
  ];

  function handleExportPDF() {
    if (sessions.length === 0 || students.length === 0) {
      toast('info', 'Belum ada data untuk diekspor. Tambahkan siswa dan kegiatan terlebih dahulu.');
      return;
    }
    exportToPDF({ students, sessions, attendance, gudep, periodeLabel: 'Dashboard - Semua Periode' });
    toast('success', 'Laporan PDF berhasil diunduh');
  }

  function handleExportExcel() {
    if (sessions.length === 0 || students.length === 0) {
      toast('info', 'Belum ada data untuk diekspor. Tambahkan siswa dan kegiatan terlebih dahulu.');
      return;
    }
    exportToExcel({ students, sessions, attendance, gudep, periodeLabel: 'Dashboard - Semua Periode' });
    toast('success', 'Laporan Excel berhasil diunduh');
  }

  if (loading) return <FullPageLoader message="Memuat dashboard..." />;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Stats cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className="card p-5 animate-slide-up" style={{ animationDelay: `${i * 80}ms` }}>
              <div className="flex items-start justify-between mb-3">
                <div className={`w-11 h-11 rounded-xl bg-${stat.color}-50 flex items-center justify-center`}>
                  <Icon size={22} className={`text-${stat.color}-600`} />
                </div>
                <span className="text-3xl font-bold text-gray-900 font-display tabular-nums">{stat.value}</span>
              </div>
              <p className="text-sm font-semibold text-gray-700">{stat.label}</p>
              <p className="text-xs text-gray-400 mt-0.5">{stat.sub}</p>
            </div>
          );
        })}
      </div>

      {/* Quick actions */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-4">
          <Award size={18} className="text-scout-600" />
          <h2 className="text-sm font-bold text-gray-900">Akses Cepat - Ekspor Laporan</h2>
        </div>
        <div className="flex flex-wrap gap-3">
          <button onClick={handleExportPDF} className="btn-primary">
            <FileDown size={18} /> Cetak Laporan PDF
          </button>
          <button onClick={handleExportExcel} className="btn-secondary">
            <FileSpreadsheet size={18} /> Ekspor Excel
          </button>
          <button onClick={() => onNavigate('presensi')} className="btn-secondary">
            <Activity size={18} /> Mulai Presensi
          </button>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-6">
          <h2 className="text-sm font-bold text-gray-900 mb-1">Proporsi Anggota per Golongan</h2>
          <p className="text-xs text-gray-400 mb-5">Distribusi anggota aktif berdasarkan golongan pramuka</p>
          {activeStudents.length > 0 ? (
            <DonutChart data={golonganData} centerLabel="Anggota" centerValue={activeStudents.length} />
          ) : (
            <EmptyState
              icon={Users}
              title="Belum ada anggota"
              message="Tambahkan data siswa untuk melihat visualisasi proporsi anggota."
              action={<button onClick={() => onNavigate('siswa')} className="btn-primary text-sm">Kelola Siswa</button>}
            />
          )}
        </div>

        <div className="card p-6">
          <h2 className="text-sm font-bold text-gray-900 mb-1">Tingkat Kehadiran per Golongan</h2>
          <p className="text-xs text-gray-400 mb-5">Persentase kehadiran siswa dalam setiap golongan</p>
          {attendance.length > 0 ? (
            <BarChart data={golonganAttendance} />
          ) : (
            <EmptyState
              icon={Activity}
              title="Belum ada data presensi"
              message="Mulai mencatat kehadiran siswa untuk melihat grafik tingkat kehadiran."
              action={<button onClick={() => onNavigate('presensi')} className="btn-primary text-sm">Mulai Presensi</button>}
            />
          )}
        </div>
      </div>

      {/* Status breakdown */}
      <div className="card p-6">
        <h2 className="text-sm font-bold text-gray-900 mb-1">Ringkasan Status Kehadiran</h2>
        <p className="text-xs text-gray-400 mb-5">Total rekaman absensi berdasarkan status kehadiran</p>
        {attendance.length > 0 ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {statusData.map((s, i) => {
              const cfg = STATUS_CONFIG[s.label as keyof typeof STATUS_CONFIG];
              const pct = attendance.length > 0 ? Math.round((s.value / attendance.length) * 100) : 0;
              return (
                <div key={i} className="relative overflow-hidden rounded-xl p-4 border border-gray-100" style={{ background: `${s.color}08` }}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`w-2.5 h-2.5 rounded-full`} style={{ background: s.color }} />
                    <span className={`text-xs font-semibold ${cfg.text}`}>{s.label}</span>
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-bold text-gray-900 font-display tabular-nums">{s.value}</span>
                    <span className="text-xs text-gray-400">({pct}%)</span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <EmptyState
            icon={TrendingUp}
            title="Belum ada data"
            message="Data kehadiran akan muncul di sini setelah Anda mulai mencatat presensi."
          />
        )}
      </div>

      {/* Recent sessions */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold text-gray-900">Kegiatan Terbaru</h2>
          <button onClick={() => onNavigate('kegiatan')} className="text-xs font-semibold text-scout-600 hover:text-scout-700">
            Lihat semua
          </button>
        </div>
        {sessions.length > 0 ? (
          <div className="space-y-2">
            {sessions.slice(0, 5).map((s) => {
              const sAttendance = attendance.filter((a) => a.session_id === s.id);
              const sHadir = sAttendance.filter((a) => a.status === 'Hadir').length;
              return (
                <div key={s.id} className="flex items-center gap-4 py-3 px-4 rounded-xl hover:bg-gray-50 transition-colors">
                  <div className="w-10 h-10 rounded-lg bg-scout-50 flex items-center justify-center shrink-0">
                    <CalendarDays size={18} className="text-scout-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-gray-900 truncate">{s.nama_kegiatan}</p>
                    <p className="text-xs text-gray-400">
                      {new Date(s.tanggal).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' })}
                      {s.golongan !== 'Semua' && ` • ${s.golongan}`}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="badge bg-scout-100 text-scout-700">{sHadir} Hadir</span>
                    <span className="badge bg-gray-100 text-gray-500">{sAttendance.length} Total</span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <EmptyState
            icon={CalendarDays}
            title="Belum ada kegiatan"
            message="Tambahkan sesi kegiatan pramuka untuk mulai mencatat presensi."
            action={<button onClick={() => onNavigate('kegiatan')} className="btn-primary text-sm">Tambah Kegiatan</button>}
          />
        )}
      </div>
    </div>
  );
}
