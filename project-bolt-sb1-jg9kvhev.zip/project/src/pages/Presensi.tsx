import { useEffect, useState, useCallback } from 'react';
import { CalendarDays, Users, Save, Search, ChevronDown, Check, Info } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { GOLONGAN_LIST, STATUS_LIST, STATUS_CONFIG, GOLONGAN_CONFIG } from '@/types';
import type { Student, Session, AttendanceRecord, AttendanceStatus, GolonganFilter } from '@/types';
import { FullPageLoader } from '@/components/Loading';
import { EmptyState } from '@/components/EmptyState';
import { toast } from '@/components/Toast';

export default function Presensi() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [students, setStudents] = useState<Student[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [golonganFilter, setGolonganFilter] = useState<GolonganFilter>('Semua');
  const [searchQuery, setSearchQuery] = useState('');
  const [draftStatus, setDraftStatus] = useState<Record<string, AttendanceStatus>>({});
  const [draftNotes, setDraftNotes] = useState<Record<string, string>>({});
  const [sessionDropdownOpen, setSessionDropdownOpen] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    const [studentsRes, sessionsRes, attendanceRes] = await Promise.all([
      supabase.from('students').select('*').order('nama'),
      supabase.from('sessions').select('*').order('tanggal', { ascending: false }),
      supabase.from('attendance').select('*'),
    ]);
    const sData = studentsRes.data || [];
    const sessData = sessionsRes.data || [];
    const aData = attendanceRes.data || [];
    setStudents(sData);
    setSessions(sessData);
    setAttendance(aData);
    if (sessData.length > 0) setSelectedSessionId(sessData[0].id);
    setLoading(false);
  }

  const selectedSession = sessions.find((s) => s.id === selectedSessionId);

  const initializeDrafts = useCallback(() => {
    if (!selectedSessionId) return;
    const dStatus: Record<string, AttendanceStatus> = {};
    const dNotes: Record<string, string> = {};
    students.forEach((s) => {
      const rec = attendance.find((a) => a.student_id === s.id && a.session_id === selectedSessionId);
      dStatus[s.id] = rec?.status || 'Hadir';
      dNotes[s.id] = rec?.keterangan || '';
    });
    setDraftStatus(dStatus);
    setDraftNotes(dNotes);
  }, [selectedSessionId, students, attendance]);

  useEffect(() => {
    initializeDrafts();
  }, [initializeDrafts]);

  const filteredStudents = students.filter((s) => {
    if (golonganFilter !== 'Semua' && s.golongan !== golonganFilter) return false;
    if (searchQuery && !s.nama.toLowerCase().includes(searchQuery.toLowerCase()) && !s.nta_nis.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    if (selectedSession && selectedSession.golongan !== 'Semua' && s.golongan !== selectedSession.golongan) return false;
    return s.aktif;
  });

  function setStatus(studentId: string, status: AttendanceStatus) {
    setDraftStatus((prev) => ({ ...prev, [studentId]: status }));
  }

  function setNote(studentId: string, note: string) {
    setDraftNotes((prev) => ({ ...prev, [studentId]: note }));
  }

  function setAllStatus(status: AttendanceStatus) {
    const newDrafts: Record<string, AttendanceStatus> = {};
    filteredStudents.forEach((s) => { newDrafts[s.id] = status; });
    setDraftStatus((prev) => ({ ...prev, ...newDrafts }));
  }

  async function handleSave() {
    if (!selectedSessionId) {
      toast('error', 'Pilih sesi kegiatan terlebih dahulu');
      return;
    }
    setSaving(true);
    try {
      const existingMap = new Map(attendance.filter((a) => a.session_id === selectedSessionId).map((a) => [a.student_id, a]));
      const upserts: { student_id: string; session_id: string; status: AttendanceStatus; keterangan: string }[] = [];
      filteredStudents.forEach((s) => {
        const status = draftStatus[s.id] || 'Hadir';
        const keterangan = draftNotes[s.id] || '';
        upserts.push({ student_id: s.id, session_id: selectedSessionId, status, keterangan });
      });

      for (const u of upserts) {
        const existing = existingMap.get(u.student_id);
        if (existing) {
          await supabase.from('attendance').update({ status: u.status, keterangan: u.keterangan }).eq('id', existing.id);
        } else {
          await supabase.from('attendance').insert(u);
        }
      }

      const { data: newAtt } = await supabase.from('attendance').select('*');
      setAttendance(newAtt || []);
      toast('success', `Presensi untuk ${upserts.length} siswa berhasil disimpan`);
    } catch {
      toast('error', 'Gagal menyimpan presensi. Silakan coba lagi.');
    }
    setSaving(false);
  }

  if (loading) return <FullPageLoader message="Memuat data presensi..." />;

  if (sessions.length === 0) {
    return (
      <div className="card">
        <EmptyState
          icon={CalendarDays}
          title="Belum ada sesi kegiatan"
          message="Anda harus membuat sesi kegiatan terlebih dahulu sebelum dapat mencatat presensi siswa."
        />
      </div>
    );
  }

  if (students.filter((s) => s.aktif).length === 0) {
    return (
      <div className="card">
        <EmptyState
          icon={Users}
          title="Belum ada siswa aktif"
          message="Tambahkan data siswa terlebih dahulu untuk mulai mencatat presensi."
        />
      </div>
    );
  }

  const hasChanges = filteredStudents.some((s) => {
    const existing = attendance.find((a) => a.student_id === s.id && a.session_id === selectedSessionId);
    const draftS = draftStatus[s.id] || 'Hadir';
    const draftN = draftNotes[s.id] || '';
    return !existing || existing.status !== draftS || existing.keterangan !== draftN;
  });

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Session selector + filters */}
      <div className="card p-5">
        <div className="flex flex-col gap-4">
          {/* Session dropdown */}
          <div className="flex flex-col sm:flex-row gap-3 sm:items-end">
            <div className="flex-1">
              <label className="block text-xs font-semibold text-gray-500 mb-1.5">Sesi Kegiatan</label>
              <div className="relative">
                <button
                  onClick={() => setSessionDropdownOpen(!sessionDropdownOpen)}
                  className="w-full flex items-center justify-between px-3.5 py-2.5 bg-white border border-gray-300 rounded-lg text-gray-900 hover:border-gray-400 transition-colors"
                >
                  <span className="text-sm font-medium truncate">
                    {selectedSession ? `${selectedSession.nama_kegiatan} — ${new Date(selectedSession.tanggal).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}` : 'Pilih sesi...'}
                  </span>
                  <ChevronDown size={18} className={`text-gray-400 transition-transform ${sessionDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                {sessionDropdownOpen && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setSessionDropdownOpen(false)} />
                    <div className="absolute z-20 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-64 overflow-y-auto animate-slide-down">
                      {sessions.map((s) => (
                        <button
                          key={s.id}
                          onClick={() => { setSelectedSessionId(s.id); setSessionDropdownOpen(false); }}
                          className={`w-full text-left px-3.5 py-2.5 hover:bg-scout-50 transition-colors border-b border-gray-50 last:border-0 ${s.id === selectedSessionId ? 'bg-scout-50' : ''}`}
                        >
                          <p className="text-sm font-semibold text-gray-900">{s.nama_kegiatan}</p>
                          <p className="text-xs text-gray-400">
                            {new Date(s.tanggal).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}
                            {s.golongan !== 'Semua' && ` • ${s.golongan}`}
                          </p>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
            <button onClick={handleSave} disabled={saving || !hasChanges} className="btn-primary">
              {saving ? <Check size={18} className="animate-pulse" /> : <Save size={18} />}
              {saving ? 'Menyimpan...' : 'Simpan Presensi'}
            </button>
          </div>

          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Cari nama atau NTA/NIS..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input-field pl-9"
              />
            </div>
            <div className="flex gap-1.5 bg-gray-100 p-1 rounded-lg overflow-x-auto">
              <button
                onClick={() => setGolonganFilter('Semua')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all whitespace-nowrap ${golonganFilter === 'Semua' ? 'bg-white text-scout-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                Semua
              </button>
              {GOLONGAN_LIST.map((g) => (
                <button
                  key={g}
                  onClick={() => setGolonganFilter(g)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all whitespace-nowrap ${golonganFilter === g ? 'bg-white text-scout-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          {/* Quick actions */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs text-gray-400 font-medium">Tandai semua:</span>
            {STATUS_LIST.map((status) => {
              const cfg = STATUS_CONFIG[status];
              return (
                <button
                  key={status}
                  onClick={() => setAllStatus(status)}
                  className={`badge ${cfg.bg} ${cfg.text} hover:opacity-80 transition-opacity cursor-pointer px-3 py-1`}
                >
                  {status}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Attendance table */}
      {filteredStudents.length > 0 ? (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">Nama Siswa</th>
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3 hidden md:table-cell">NTA/NIS</th>
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3 hidden sm:table-cell">Golongan</th>
                  <th className="text-center text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3">Status</th>
                  <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider px-4 py-3 min-w-[180px]">Keterangan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredStudents.map((student) => {
                  const status = draftStatus[student.id] || 'Hadir';
                  const golCfg = GOLONGAN_CONFIG[student.golongan];
                  return (
                    <tr key={student.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full ${student.ambalan === 'Putra' ? 'bg-blue-100' : 'bg-pink-100'} flex items-center justify-center text-xs font-bold ${student.ambalan === 'Putra' ? 'text-blue-600' : 'text-pink-600'}`}>
                            {student.nama.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-gray-900">{student.nama}</p>
                            <p className="text-xs text-gray-400 md:hidden">{student.nta_nis}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600 hidden md:table-cell">{student.nta_nis || '-'}</td>
                      <td className="px-4 py-3 hidden sm:table-cell">
                        <span className={`badge ${golCfg.bg} ${golCfg.text}`}>{student.golongan}</span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1 justify-center">
                          {STATUS_LIST.map((s) => {
                            const cfg = STATUS_CONFIG[s];
                            const isActive = status === s;
                            return (
                              <button
                                key={s}
                                onClick={() => setStatus(student.id, s)}
                                title={s}
                                className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${isActive ? `${cfg.bg} ${cfg.text} ring-2 ring-offset-1 ring-current scale-105` : 'bg-gray-100 text-gray-400 hover:bg-gray-200'}`}
                              >
                                {s.charAt(0)}
                              </button>
                            );
                          })}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <input
                          type="text"
                          placeholder="Keterangan..."
                          value={draftNotes[student.id] || ''}
                          onChange={(e) => setNote(student.id, e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-scout-500 focus:border-transparent transition-all"
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {/* Summary bar */}
          <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-t border-gray-200">
            <div className="flex items-center gap-1.5 text-xs text-gray-500">
              <Info size={14} />
              <span>{filteredStudents.length} siswa</span>
            </div>
            <div className="flex items-center gap-3">
              {STATUS_LIST.map((s) => {
                const cfg = STATUS_CONFIG[s];
                const count = filteredStudents.filter((stu) => (draftStatus[stu.id] || 'Hadir') === s).length;
                return (
                  <span key={s} className="flex items-center gap-1 text-xs">
                    <span className={`w-2 h-2 rounded-full ${cfg.dot}`} />
                    <span className="font-semibold text-gray-700 tabular-nums">{count}</span>
                  </span>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        <div className="card">
          <EmptyState
            icon={Search}
            title="Tidak ada siswa"
            message="Tidak ada siswa yang sesuai dengan filter yang dipilih untuk sesi ini."
          />
        </div>
      )}
    </div>
  );
}
