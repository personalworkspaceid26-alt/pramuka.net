import { useEffect, useState } from 'react';
import { Save, Settings, Building2, Users, Award } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Gudep } from '@/types';
import { FullPageLoader } from '@/components/Loading';
import { toast } from '@/components/Toast';

interface PengaturanProps {
  gudep: Gudep | null;
  onGudepChange: (g: Gudep) => void;
}

export default function Pengaturan({ gudep, onGudepChange }: PengaturanProps) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Gudep | null>(null);

  useEffect(() => {
    if (gudep) {
      setForm(gudep);
      setLoading(false);
    } else {
      loadGudep();
    }
  }, [gudep]);

  async function loadGudep() {
    const { data } = await supabase.from('gudep').select('*').limit(1).maybeSingle();
    if (data) {
      setForm(data);
    }
    setLoading(false);
  }

  async function handleSave() {
    if (!form) return;
    setSaving(true);
    try {
      const { data, error } = await supabase.from('gudep').update({
        nama_pangkalan: form.nama_pangkalan,
        nomor_gudep: form.nomor_gudep,
        ambalan_putra: form.ambalan_putra,
        ambalan_putri: form.ambalan_putri,
        alamat: form.alamat,
        telepon: form.telepon,
        nama_pembina: form.nama_pembina,
        nip_pembina: form.nip_pembina,
        pradana_putra: form.pradana_putra,
        pradana_putri: form.pradana_putri,
        updated_at: new Date().toISOString(),
      }).eq('id', form.id).select().maybeSingle();

      if (error) throw error;
      if (data) onGudepChange(data);
      toast('success', 'Identitas pangkalan berhasil disimpan');
    } catch {
      toast('error', 'Gagal menyimpan identitas pangkalan');
    }
    setSaving(false);
  }

  function update<K extends keyof Gudep>(key: K, value: Gudep[K]) {
    if (!form) return;
    setForm({ ...form, [key]: value });
  }

  if (loading || !form) return <FullPageLoader message="Memuat pengaturan..." />;

  return (
    <div className="space-y-5 animate-fade-in max-w-4xl">
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-1">
          <Settings size={18} className="text-scout-600" />
          <h2 className="text-lg font-bold text-gray-900 font-display">Pengaturan Identitas Pangkalan</h2>
        </div>
        <p className="text-xs text-gray-400">Atur identitas gudep yang akan tampil di header, dashboard, dan laporan resmi PDF.</p>
      </div>

      {/* Identitas Pangkalan */}
      <div className="card p-6">
        <div className="flex items-center gap-2 mb-5">
          <div className="w-9 h-9 rounded-lg bg-scout-50 flex items-center justify-center">
            <Building2 size={18} className="text-scout-600" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Identitas Pangkalan & Gugus Depan</h3>
            <p className="text-xs text-gray-400">Informasi resmi sekolah/pangkalan pramuka</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Nama Sekolah / Pangkalan</label>
            <input type="text" value={form.nama_pangkalan} onChange={(e) => update('nama_pangkalan', e.target.value)} className="input-field" placeholder="Contoh: SD Negeri 1 Harapan Bangsa" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Nomor Gugus Depan (Gudep)</label>
            <input type="text" value={form.nomor_gudep} onChange={(e) => update('nomor_gudep', e.target.value)} className="input-field" placeholder="Contoh: 01.02.03" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Nomor Telepon / Kontak</label>
            <input type="text" value={form.telepon} onChange={(e) => update('telepon', e.target.value)} className="input-field" placeholder="Contoh: 021-1234567" />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Alamat Sekolah / Pangkalan</label>
            <textarea value={form.alamat} onChange={(e) => update('alamat', e.target.value)} className="input-field min-h-[60px] resize-y" placeholder="Alamat lengkap pangkalan pramuka" />
          </div>
        </div>
      </div>

      {/* Ambalan */}
      <div className="card p-6">
        <div className="flex items-center gap-2 mb-5">
          <div className="w-9 h-9 rounded-lg bg-forest-50 flex items-center justify-center">
            <Users size={18} className="text-forest-600" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Nama Ambalan</h3>
            <p className="text-xs text-gray-400">Nama ambalan untuk Putra dan Putri</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Nama Ambalan Putra</label>
            <input type="text" value={form.ambalan_putra} onChange={(e) => update('ambalan_putra', e.target.value)} className="input-field" placeholder="Contoh: Setia Bakti" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Nama Ambalan Putri</label>
            <input type="text" value={form.ambalan_putri} onChange={(e) => update('ambalan_putri', e.target.value)} className="input-field" placeholder="Contoh: Bunga Tanjung" />
          </div>
        </div>
      </div>

      {/* Pembina & Pradana */}
      <div className="card p-6">
        <div className="flex items-center gap-2 mb-5">
          <div className="w-9 h-9 rounded-lg bg-earth-50 flex items-center justify-center">
            <Award size={18} className="text-earth-600" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Pembina & Pradana</h3>
            <p className="text-xs text-gray-400">Data untuk blok tanda tangan laporan resmi</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Nama Pembina Gugus Depan</label>
            <input type="text" value={form.nama_pembina} onChange={(e) => update('nama_pembina', e.target.value)} className="input-field" placeholder="Nama pembina gugus depan" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">NIP Pembina</label>
            <input type="text" value={form.nip_pembina} onChange={(e) => update('nip_pembina', e.target.value)} className="input-field" placeholder="NIP pembina (untuk laporan)" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Pradana Putra</label>
            <input type="text" value={form.pradana_putra} onChange={(e) => update('pradana_putra', e.target.value)} className="input-field" placeholder="Nama pradana ambalan putra" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Pradana Putri</label>
            <input type="text" value={form.pradana_putri} onChange={(e) => update('pradana_putri', e.target.value)} className="input-field" placeholder="Nama pradana ambalan putri" />
          </div>
        </div>
      </div>

      {/* Save button */}
      <div className="flex justify-end">
        <button onClick={handleSave} disabled={saving} className="btn-primary">
          <Save size={18} /> {saving ? 'Menyimpan...' : 'Simpan Pengaturan'}
        </button>
      </div>
    </div>
  );
}
