import { useMemo } from 'react';

interface BarChartProps {
  data: { label: string; value: number; color?: string }[];
  max?: number;
  unit?: string;
}

export default function BarChart({ data, max, unit = '%' }: BarChartProps) {
  const maxVal = max ?? Math.max(...data.map((d) => d.value), 1);

  const bars = useMemo(() => {
    return data.map((d) => ({
      ...d,
      heightPct: maxVal > 0 ? (d.value / maxVal) * 100 : 0,
    }));
  }, [data, maxVal]);

  return (
    <div className="flex items-end gap-4 h-48 px-2">
      {bars.map((bar, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
          <span className="text-xs font-semibold text-gray-700 tabular-nums">
            {bar.value}{unit}
          </span>
          <div className="w-full flex flex-col justify-end h-full" style={{ maxHeight: '140px' }}>
            <div
              className="w-full rounded-t-md transition-all duration-700 ease-out hover:opacity-80"
              style={{
                height: `${bar.heightPct}%`,
                background: bar.color || '#16a34a',
                minHeight: bar.value > 0 ? '4px' : '0',
              }}
            />
          </div>
          <span className="text-xs text-gray-500 font-medium text-center truncate w-full">
            {bar.label}
          </span>
        </div>
      ))}
    </div>
  );
}
