import { useEffect, useState } from 'react';
import { CheckCircle2, XCircle, Info, X } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'info';

export interface Toast {
  id: string;
  type: ToastType;
  message: string;
}

let toastIdCounter = 0;
let addToastFn: ((type: ToastType, message: string) => void) | null = null;

export function toast(type: ToastType, message: string) {
  if (addToastFn) addToastFn(type, message);
}

const config = {
  success: { icon: CheckCircle2, bg: 'bg-scout-600', iconColor: 'text-white' },
  error: { icon: XCircle, bg: 'bg-red-500', iconColor: 'text-white' },
  info: { icon: Info, bg: 'bg-blue-500', iconColor: 'text-white' },
};

export function ToastContainer() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    addToastFn = (type: ToastType, message: string) => {
      const id = `toast-${++toastIdCounter}`;
      setToasts((prev) => [...prev, { id, type, message }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 3500);
    };
    return () => {
      addToastFn = null;
    };
  }, []);

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <div className="fixed top-5 right-5 z-[100] flex flex-col gap-2.5 pointer-events-none">
      {toasts.map((t) => {
        const { icon: Icon, bg, iconColor } = config[t.type];
        return (
          <div
            key={t.id}
            className={`flex items-center gap-3 ${bg} text-white px-4 py-3 rounded-xl shadow-lg animate-slide-down max-w-sm pointer-events-auto`}
          >
            <Icon size={20} className={iconColor} />
            <span className="text-sm font-medium flex-1">{t.message}</span>
            <button onClick={() => removeToast(t.id)} className="shrink-0 opacity-80 hover:opacity-100">
              <X size={16} />
            </button>
          </div>
        );
      })}
    </div>
  );
}
