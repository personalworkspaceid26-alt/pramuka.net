import { Loader2 } from 'lucide-react';

export function LoadingSpinner({ size = 24, className = '' }: { size?: number; className?: string }) {
  return <Loader2 size={size} className={`animate-spin text-scout-600 ${className}`} />;
}

export function FullPageLoader({ message = 'Memuat data...' }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3">
      <LoadingSpinner size={32} />
      <p className="text-sm text-gray-500 font-medium">{message}</p>
    </div>
  );
}
