import { useMemo } from 'react';

interface DonutChartProps {
  data: { label: string; value: number; color: string }[];
  centerLabel?: string;
  centerValue?: string | number;
  size?: number;
}

export default function DonutChart({ data, centerLabel, centerValue, size = 200 }: DonutChartProps) {
  const total = data.reduce((sum, d) => sum + d.value, 0);
  const radius = size / 2;
  const strokeWidth = 28;
  const innerRadius = radius - strokeWidth;
  const circumference = 2 * Math.PI * (radius - strokeWidth / 2);

  const segments = useMemo(() => {
    let offset = 0;
    return data.map((d) => {
      const fraction = total > 0 ? d.value / total : 0;
      const dash = fraction * circumference;
      const segment = {
        ...d,
        dash,
        gap: circumference - dash,
        offset: -offset,
        fraction,
      };
      offset += dash;
      return segment;
    });
  }, [data, circumference, total]);

  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-center sm:gap-6">
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle
            cx={radius}
            cy={radius}
            r={radius - strokeWidth / 2}
            fill="none"
            stroke="#f3f4f6"
            strokeWidth={strokeWidth}
          />
          {total > 0 &&
            segments.map((seg, i) => (
              <circle
                key={i}
                cx={radius}
                cy={radius}
                r={radius - strokeWidth / 2}
                fill="none"
                stroke={seg.color}
                strokeWidth={strokeWidth}
                strokeDasharray={`${seg.dash} ${seg.gap}`}
                strokeDashoffset={seg.offset}
                strokeLinecap="butt"
                className="transition-all duration-700 ease-out"
              />
            ))}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-bold text-gray-900 font-display">
            {centerValue !== undefined ? centerValue : total}
          </span>
          {centerLabel && (
            <span className="text-xs font-medium text-gray-500 mt-0.5">{centerLabel}</span>
          )}
        </div>
      </div>
      <div className="flex flex-col gap-2 w-full">
        {data.map((d, i) => {
          const pct = total > 0 ? ((d.value / total) * 100).toFixed(1) : '0.0';
          return (
            <div key={i} className="flex items-center gap-2.5 text-sm">
              <span className="w-3 h-3 rounded-full shrink-0" style={{ background: d.color }} />
              <span className="text-gray-600 font-medium flex-1">{d.label}</span>
              <span className="text-gray-900 font-semibold tabular-nums">{d.value}</span>
              <span className="text-gray-400 text-xs tabular-nums w-12 text-right">{pct}%</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
